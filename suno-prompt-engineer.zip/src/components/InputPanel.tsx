import { motion, AnimatePresence } from 'motion/react';
import { Mic, Music, Wand2, AlignLeft, Sparkles, Loader2, Settings2 } from 'lucide-react';
import { GenerationMode } from '../types';

interface InputPanelProps {
  prompt: string;
  setPrompt: (value: string) => void;
  isInstrumental: boolean;
  setIsInstrumental: (value: boolean) => void;
  mode: GenerationMode;
  setMode: (mode: GenerationMode) => void;
  isAutoMode: boolean;
  setIsAutoMode: (value: boolean) => void;
  isLoading: boolean;
  loadingStep: string;
  onGenerate: () => void;
  hasResult: boolean;
  onOpenSettings: () => void;
  userLyrics: string;
  setUserLyrics: (value: string) => void;
}

export function InputPanel({
  prompt,
  setPrompt,
  isInstrumental,
  setIsInstrumental,
  mode,
  setMode,
  isAutoMode,
  setIsAutoMode,
  isLoading,
  loadingStep,
  onGenerate,
  hasResult,
  onOpenSettings,
  userLyrics,
  setUserLyrics
}: InputPanelProps) {
  return (
    <div className="theme-glass border border-white/5 p-5 md:p-8 shadow-2xl transition-colors duration-500 rounded-[2.5rem] md:rounded-[var(--radius)]">
      <div className="flex flex-col sm:flex-row gap-4 mb-6 md:mb-8">
        <motion.div 
          className="ios-segmented flex-1 relative bg-black/20 p-1.5 rounded-2xl flex touch-pan-y select-none"
          onPanEnd={(e, info) => {
            const threshold = 20;
            if (info.offset.x > threshold && !isInstrumental) {
              setIsInstrumental(true);
            } else if (info.offset.x < -threshold && isInstrumental) {
              setIsInstrumental(false);
            }
          }}
        >
          <button
            onClick={() => setIsInstrumental(false)}
            className={`flex-1 py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors font-semibold min-h-[44px] ios-segmented-item ${!isInstrumental ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            {!isInstrumental && (
              <motion.div 
                layoutId="segmented-active" 
                className="ios-segmented-active will-change-transform transform-gpu"
                transition={{ type: 'spring', bounce: 0.15, stiffness: 400, damping: 30 }}
              />
            )}
            <Mic className="w-4 h-4 relative z-10" />
            <span className="relative z-10">Se zpěvem</span>
          </button>
          <button
            onClick={() => setIsInstrumental(true)}
            className={`flex-1 py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors font-semibold min-h-[44px] ios-segmented-item ${isInstrumental ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            {isInstrumental && (
              <motion.div 
                layoutId="segmented-active" 
                className="ios-segmented-active will-change-transform transform-gpu"
                transition={{ type: 'spring', bounce: 0.15, stiffness: 400, damping: 30 }}
              />
            )}
            <Music className="w-4 h-4 relative z-10" />
            <span className="relative z-10">Instrumental</span>
          </button>
        </motion.div>

        <motion.div 
          className="ios-segmented flex-1 relative bg-black/20 p-1.5 rounded-2xl flex touch-pan-y select-none"
          onPanEnd={(e, info) => {
            const threshold = 20;
            if (info.offset.x > threshold && mode === 'generate') {
              setMode('refine');
            } else if (info.offset.x < -threshold && mode === 'refine') {
              setMode('generate');
            }
          }}
        >
          <button
            onClick={() => setMode('generate')}
            className={`flex-1 py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors font-semibold min-h-[44px] ios-segmented-item ${mode === 'generate' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            {mode === 'generate' && (
              <motion.div 
                layoutId="mode-segmented-active" 
                className="ios-segmented-active will-change-transform transform-gpu"
                transition={{ type: 'spring', bounce: 0.15, stiffness: 400, damping: 30 }}
              />
            )}
            <Wand2 className="w-4 h-4 relative z-10" />
            <span className="relative z-10">Generovat</span>
          </button>
          <button
            onClick={() => setMode('refine')}
            className={`flex-1 py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors font-semibold min-h-[44px] ios-segmented-item ${mode === 'refine' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            {mode === 'refine' && (
              <motion.div 
                layoutId="mode-segmented-active" 
                className="ios-segmented-active will-change-transform transform-gpu"
                transition={{ type: 'spring', bounce: 0.15, stiffness: 400, damping: 30 }}
              />
            )}
            <AlignLeft className="w-4 h-4 relative z-10" />
            <span className="relative z-10">Vylepšit</span>
          </button>
        </motion.div>
      </div>

      <AnimatePresence>
        {mode === 'refine' && (
          <motion.div
            initial={{ opacity: 0, height: 0, marginBottom: 0 }}
            animate={{ opacity: 1, height: 'auto', marginBottom: 24 }}
            exit={{ opacity: 0, height: 0, marginBottom: 0 }}
            className="overflow-hidden will-change-transform transform-gpu"
          >
            <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl text-indigo-200 text-sm">
              <p className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 mt-0.5 shrink-0 text-indigo-400" />
                <span>
                  <strong>Režim Vylepšit:</strong> Vložte svůj existující prompt nebo nápad. AI ho zanalyzuje, opraví strukturu, doplní chybějící meta tagy a optimalizuje pro Suno v5.
                </span>
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative group">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder={mode === 'generate' 
            ? "Popište svou píseň... (např. 'Epická orchestrální skladba o dobývání vesmíru, temná a dramatická')"
            : "Vložte svůj existující prompt k vylepšení..."}
          className="w-full h-32 md:h-40 bg-black/20 border border-white/10 rounded-2xl md:rounded-3xl p-4 md:p-6 text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-[var(--theme-primary)]/50 focus:border-[var(--theme-primary)]/50 transition-all resize-none text-base md:text-lg shadow-inner"
          disabled={isLoading}
        />
        <div className="absolute bottom-4 right-4 flex items-center gap-3">
          <button
            onClick={onOpenSettings}
            className="p-2 bg-black/40 hover:bg-black/60 border border-white/5 rounded-xl transition-colors text-zinc-400 hover:text-white"
            title="Pokročilé nastavení"
          >
            <Settings2 className="w-4 h-4" />
          </button>
          <label className="flex items-center gap-2 cursor-pointer group/toggle bg-black/40 px-3 py-1.5 rounded-xl border border-white/5 hover:bg-black/60 transition-colors">
            <div className="relative">
              <input 
                type="checkbox" 
                className="sr-only" 
                checked={isAutoMode}
                onChange={(e) => setIsAutoMode(e.target.checked)}
                disabled={isLoading}
              />
              <div className={`block w-10 h-6 rounded-full transition-colors ${isAutoMode ? 'bg-[var(--theme-primary)]' : 'bg-zinc-700'}`}></div>
              <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${isAutoMode ? 'translate-x-4' : ''}`}></div>
            </div>
            <span className="text-xs font-medium text-zinc-300 group-hover/toggle:text-white transition-colors">Auto Mode</span>
          </label>
        </div>
      </div>

      <AnimatePresence>
        {mode === 'refine' && (
          <motion.div
            initial={{ opacity: 0, height: 0, marginTop: 0 }}
            animate={{ opacity: 1, height: 'auto', marginTop: 24 }}
            exit={{ opacity: 0, height: 0, marginTop: 0 }}
            className="overflow-hidden will-change-transform transform-gpu"
          >
            <textarea
              value={userLyrics}
              onChange={(e) => setUserLyrics(e.target.value)}
              placeholder="Vložte původní text písně, který chcete vylepšit..."
              className="w-full h-48 bg-black/20 border border-white/10 rounded-2xl md:rounded-3xl p-4 md:p-6 text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-[var(--theme-primary)]/50 focus:border-[var(--theme-primary)]/50 transition-all resize-none text-base md:text-lg shadow-inner"
              disabled={isLoading}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-6 md:mt-8">
        <button
          onClick={onGenerate}
          disabled={isLoading || !prompt.trim()}
          className="w-full relative group overflow-hidden rounded-2xl md:rounded-3xl p-[1px] transition-transform active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100 min-h-[56px] md:min-h-[64px]"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-[var(--primary)] via-[var(--secondary)] to-[var(--primary)] opacity-70 group-hover:opacity-100 transition-opacity duration-500 bg-[length:200%_auto] animate-gradient" />
          <div className="relative h-full w-full bg-zinc-950/50 backdrop-blur-sm rounded-[calc(1.5rem-1px)] md:rounded-[calc(1.5rem-1px)] flex items-center justify-center px-8 py-4 md:py-5 border border-white/10 group-hover:bg-transparent transition-colors duration-500">
            {isLoading && (
              <motion.div 
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
                animate={{ x: ['-100%', '100%'] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
              />
            )}
            
            {isLoading ? (
              <div className="relative z-10 flex items-center justify-center gap-3 w-full">
                <Loader2 className="w-5 h-5 animate-spin shrink-0" />
                <span className="text-[14px] leading-tight font-medium text-center whitespace-normal line-clamp-2 drop-shadow-md">
                  {loadingStep || 'Pracuji...'}
                </span>
              </div>
            ) : (
              <div className="relative z-10 flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 shrink-0" />
                <span className="text-[17px] font-semibold tracking-tight">
                  Vygenerovat Prompt
                </span>
              </div>
            )}
          </div>
        </button>
      </div>
    </div>
  );
}
