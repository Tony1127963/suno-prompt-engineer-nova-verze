import { useState, useEffect, useMemo } from 'react';
import { Theme, THEMES } from '../constants';

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('suno-theme');
    const defaultTheme = THEMES[0];
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { ...defaultTheme, ...parsed };
      } catch (e) {
        return defaultTheme;
      }
    }
    return defaultTheme;
  });

  useEffect(() => {
    localStorage.setItem('suno-theme', JSON.stringify(theme));
  }, [theme]);

  // Apply CSS variables
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--theme-primary', theme.primary);
    root.style.setProperty('--theme-secondary', theme.secondary);
    root.style.setProperty('--theme-bg', theme.background);
    root.style.setProperty('--theme-glass', theme.glassColor);
    root.style.setProperty('--theme-glass-opacity', theme.glassOpacity.toString());
    root.style.setProperty('--theme-blur', `${theme.blur}px`);
    root.style.setProperty('--theme-radius', `${theme.radius}rem`);
    root.style.setProperty('--theme-glow', theme.glow.toString());
    root.style.setProperty('--theme-panel-opacity', theme.panelOpacity.toString());
    root.style.setProperty('--theme-panel-blur', `${theme.panelBlur}px`);
    root.style.setProperty('--theme-border-opacity', theme.borderOpacity.toString());
    root.style.setProperty('--theme-shadow-intensity', theme.shadowIntensity.toString());
    root.style.setProperty('--theme-font', theme.fontFamily === 'mono' ? 'var(--font-mono)' : 'var(--font-sans)');
    root.style.setProperty('--theme-ai-panel', theme.aiPanelColor);
    root.style.setProperty('--theme-ai-panel-opacity', theme.aiPanelOpacity.toString());
  }, [theme]);

  const resetToAuto = () => {
    setTheme(THEMES[0]);
  };

  return { theme, setTheme, resetToAuto };
}
